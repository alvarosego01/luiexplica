# Avada Child Theme for AdswinMkt

This project is a small and simple child theme for the AdswinMkt website ([adswinmkt.com](https://www.adswinmkt.com/)). It handles custom configurations, styles, and solutions tailored to the site's specific needs.
